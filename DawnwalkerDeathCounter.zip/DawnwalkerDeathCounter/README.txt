DawnwalkerDeathCounter — prosty licznik zgonów dla OBS

Zawartość:
- enabled.txt
- Scripts/main.lua

Instalacja tego moda:
1. Najpierw zainstaluj działające UE4SS przeznaczone konkretnie dla aktualnego buildu The Blood of Dawnwalker.
2. Skopiuj cały folder DawnwalkerDeathCounter do:
   ...\The Blood of Dawnwalker\Dawnwalker\Binaries\Win64\ue4ss\Mods\
3. Uruchom grę.
4. Po załadowaniu postaci powinien powstać plik:
   ...\ue4ss\Mods\DawnwalkerDeathCounter\counter.txt
5. W OBS dodaj źródło Tekst (GDI+) -> Odczytaj z pliku i wskaż counter.txt.

Działanie:
- Skrypt odczytuje Health.CurrentValue gracza co 250 ms.
- Liczy tylko przejście z żywego gracza do HP <= 0, więc jedna śmierć nie powinna naliczać się wielokrotnie.
- Licznik zapisuje się w counter.txt i pozostaje po ponownym uruchomieniu gry.

Opcjonalne komendy UE4SS:
- deathcounter_add   -> testowe +1
- deathcounter_reset -> reset do 0

Ważne:
- UE4SS jest zależne od konkretnego buildu gry. Po aktualizacji The Blood of Dawnwalker sprawdź zgodność UE4SS przed uruchomieniem.
- Ten skrypt nie modyfikuje save'a ani statystyk postaci; odczytuje stan HP i zapisuje wyłącznie własny plik tekstowy.
