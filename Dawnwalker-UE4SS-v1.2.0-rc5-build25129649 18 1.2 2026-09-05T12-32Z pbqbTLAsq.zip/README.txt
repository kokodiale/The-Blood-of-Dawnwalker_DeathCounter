THE BLOOD OF DAWNWALKER - UE4SS
Version 1.2.0-rc5

ABOUT

This is an unofficial, ready-to-install Dawnwalker build of UE4SS, based on
upstream standard experimental build v3.0.1-1111-g97b7e501 and pinned source
commit 97b7e501c19d8b2b7c662feee73aaa0dc1f0a4d1.

RC5 replaces the stock UE4SS.dll with a locally built, targeted
FStructProperty out/ref lifetime and marshalling patch. The stock proxy DLL,
settings, helper scripts, SDK backend, licences and helper enablement remain
byte-identical to RC4. Signature and vtable comments now identify the tested
build 25129649; their executable patterns, callbacks and layout entries are
unchanged. No game files or game assets are included.

SUPPORTED BUILD

  Store: Steam
  Steam AppID: 3751260
  Steam build ID: 25129649
  Game version: dw1-pc-257186-shipping-patch2-all-CL-257186
  Unreal Engine: 5.5.4
  Dawnwalker.exe size: 176196472 bytes
  Dawnwalker.exe SHA-256:
    7AD7D09645B0589DC0FF78B53AA1A7B18ECA79B1B7F888B403AB41D88AC7E853

Treat the package as incompatible after a game update until the new executable
has been tested. A mismatched signature can crash or hang the game.

INSTALLATION

1. Close the game.
2. Open:

   ...\SteamLibrary\steamapps\common\The Blood of Dawnwalker\Dawnwalker\Binaries\Win64\

3. Back up any existing dwmapi.dll and ue4ss folder, then move those existing
   loader files out of Win64 before extracting this package. Keep the backup
   outside Win64 and preserve third-party Mods, their configuration and mod-list
   entries. Do not overwrite an existing loader in place or leave mixed files.
4. Extract the contents of this archive into the Win64 folder.
5. Start the game through Steam.
6. After a successful clean startup, close the game and reintroduce compatible
   third-party mods and their configuration from the backup. Preserve this
   package's loader settings, signatures and helper defaults; review mod-list
   entries instead of copying the old loader configuration wholesale.

The Win64 folder should contain dwmapi.dll beside Dawnwalker.exe, plus the
ue4ss folder supplied here.

THIS CONFIGURATION

The package keeps the official standard release's helper-mod defaults:

  Enabled:  CheatManagerEnablerMod, ConsoleCommandsMod, ConsoleEnablerMod,
            BPML_GenericFunctions, BPModLoaderMod, Keybinds
  Disabled: SplitScreenMod, LineTraceMod

The external UE4SS debug consoles and hot reload are disabled for an ordinary
player installation. ProcessLocalScriptFunction is enabled and uses the
Dawnwalker-specific signature in this package.

The included VTableLayout.ini changes only UE4SS's UEngine::LoadMap lookup for
this game build. It selects vtable slot 0x4F0, which resolved to executable RVA
0x146214C during the recorded runtime tests. It does not patch UE4SS.dll or the
game executable.

TESTED BEHAVIOR

On Steam build 25129649, the RC4 baseline--both Dawnwalker signatures,
ProcessLocalScriptFunction and
LoadMap enabled, the narrow vtable layout, and the default helper mods--passed
cold startup to the main menu, loading an existing save into gameplay, an F9
quick-load back to gameplay, normal exit, and a second cold launch.

The LoadMap prehook and posthook installed at the corrected function. On the
previous Steam build 25107392 only, a separate harmless main-menu probe proved
one exact non-native Blueprint
RegisterHook path and one RegisterCustomEvent path. Both callbacks executed on
hover entry point 206 and unhover entry point 211. The probe is test evidence
only and is not included in this package. Those exact callback activations
have not been re-tested on build 25129649.

On build 25129649, the exact RC5 DLL passed smooth gameplay and F9 quick-load,
followed by a targeted gameplay regression test for the exact
Dawnwalker Lua lane that obtains FGameplayAttribute from a UFunction output
array and reuses it as an exact FStructProperty ref argument. One retained
SprintStaminaCostMultiplier descriptor survived disposal of its parent output
table and forced Lua garbage collection, then completed 25/25
apply/readback/restore cycles. A normal table-backed FVector ref/out lane also
completed 25/25 cycles. The player fingerprint stayed unchanged, all four
tested stamina values finished at their original value of 1. All 29 save-file
paths/sizes/hashes stayed unchanged against the immediate pre-probe snapshot.
The earlier RC4 startup changed RebelSettings.sav; no assistant save edit or
restore was performed. After probe removal, RC5 passed a fresh main-menu launch
and normal exit, and the restored RC4 installation passed the same rollback
check. The test probe and its logs are not included.

These tests used the exact DLL and semantically unchanged runtime support
files. Package inspection alone is not evidence of runtime compatibility.

This is targeted evidence, not a generic guarantee for every UE4SS mod,
Blueprint function, USTRUCT, or UObject-reference topology. In particular,
arbitrary owned structs containing strong UObject references, third-party
property pushers that bypass UE4SS error helpers, and raw Lua OOM/panic paths
remain outside the tested guarantee. External C++ source consumers of changed
internal-looking frame helper types may require recompilation.

If a mod fails, report the Steam build ID, the complete ue4ss\UE4SS.log, the
enabled-mod list, and exact reproduction steps. The Unreal Engine crash
reporter output alone is not enough to diagnose UE4SS.

The included ConsoleEnablerMod completed its setup in logs, but F10 and the
Swedish Section key did not show a visible in-game console during testing.
This package makes no visible-console claim.

TROUBLESHOOTING

If the game stops at a black screen or crashes after an update:

1. Close the game.
2. Restore the backup made before installation, or follow UNINSTALLATION below.
3. Verify the current Steam build ID and Dawnwalker.exe SHA-256 before reporting
   the problem.
4. Include ue4ss\UE4SS.log, your enabled-mod list, and exact reproduction
   steps. Do not submit only the Unreal Engine crash report.

Do not combine DLLs, signatures, or settings from several UE4SS packages unless
you can test the combined configuration.

UNINSTALLATION

If this package is your only UE4SS installation, close the game and remove the
dwmapi.dll and ue4ss folder that came from this archive. Remove README.txt,
THIRD_PARTY_NOTICES.txt, and SHA256SUMS.txt if they came from this package.

If you had UE4SS or UE4SS mods before installing, restore your backup instead.
Do not delete another mod's files.

INTEGRITY AND PROVENANCE

Official upstream base archive:
  UE4SS_v3.0.1-1111-g97b7e501.zip
  SHA-256:
    1BFB8DD545B5DC2B2BCC2A57175B30BC3370CA916CD931A29F7A26133D672692

UE4SS source:
  https://github.com/UE4SS-RE/RE-UE4SS

Pinned source commit:
  https://github.com/UE4SS-RE/RE-UE4SS/commit/97b7e501c19d8b2b7c662feee73aaa0dc1f0a4d1

Locally built RC5 UE4SS.dll:
  Size: 20482048 bytes
  SHA-256:
    131E53224AC52222A128F2BE2476C43ABAA495B3F8538053BD4C6FE82FCCBD30

The RC5 source delta is limited to the targeted UFunction-frame,
FStructProperty ref/out, escaping-struct ownership, nested-container lifetime,
and Lua error-unwind paths documented by this release. The full source is not
bundled in the player archive; the pinned upstream repository and commit above
are the base provenance.

The per-file hashes are listed in SHA256SUMS.txt.

CREDITS AND LICENCE

UE4SS was created by the UE4SS-RE contributors and is distributed under the MIT
License. The upstream licence and copyright notice are included unchanged at
ue4ss\LICENSE. See THIRD_PARTY_NOTICES.txt for package provenance and known
source-licence gaps. Additional verbatim licence texts are under
ue4ss\THIRD_PARTY_LICENSES\.

This package is unofficial and is not affiliated with UE4SS-RE, Rebel Wolves,
Bandai Namco Entertainment, Nexus Mods, Steam, or Valve.
