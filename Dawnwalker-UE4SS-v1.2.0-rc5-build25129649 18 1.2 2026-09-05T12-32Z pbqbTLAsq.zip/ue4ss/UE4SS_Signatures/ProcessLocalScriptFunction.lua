-- THE BLOOD OF DAWNWALKER BUILD-PINNED UE4SS COMPATIBILITY SIGNATURE
--
-- Supported retail build:
--   Steam AppID: 3751260
--   Steam build ID: 25129649
--   Executable version: dw1-pc-257186-shipping-patch2-all-CL-257186
--   Unreal Engine: 5.5.4
--   Dawnwalker.exe size: 176196472 bytes
--   Dawnwalker.exe SHA-256:
--     7AD7D09645B0589DC0FF78B53AA1A7B18ECA79B1B7F888B403AB41D88AC7E853
--
-- This pattern has exactly one match in the supported executable:
--   PE file offset: 0x12037FC
--   image RVA:      0x12041FC
--
-- Historical tests on 4 September 2026, on previous Steam build 25107392,
-- passed selected exact non-native Blueprint RegisterHook and RegisterCustomEvent
-- callback paths with the stock UE4SS DLL. Those exact callback activations have
-- not been re-tested on build 25129649. On this build, the unchanged signature
-- resolves successfully with both RC4 and RC5 and loader/gameplay smoke tests pass.
-- Never reuse this signature for a different executable SHA-256 or after an
-- unverified game update.

function Register()
    return "48 89 5C 24 08 48 89 74 24 20 57 48 83 EC 70 48 8B 05 ?? ?? ?? ?? 48 33 C4 48 89 44 24 60 48 8B 72 10 49 8B F8 48 8B 42 20 48 8B DA 80 38 04"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end
