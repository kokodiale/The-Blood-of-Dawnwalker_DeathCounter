-- THE BLOOD OF DAWNWALKER BUILD-PINNED UE4SS COMPATIBILITY SIGNATURE
--
-- Supported retail build:
--   Steam AppID: 3751260
--   Steam build ID: 25129649
--   Executable version: dw1-pc-257186-shipping-patch2-all-CL-257186
--   Unreal Engine: 5.5.4
--   Dawnwalker.exe size: 176196472 bytes
--   Dawnwalker.exe SHA-256:
--     7AD7D09645B0589DC0FF78B53AA1A7B18ECA79B1B7F888B403AB41D88AC7E853
--
-- This 33-byte pattern has exactly one match in that executable. The match is
-- the start of FName::FName(wchar_t const*, EFindName):
--   PE file offset: 0x1059460
--   image RVA:      0x1059E60
--
-- The four wildcard bytes are the build-specific RIP-relative displacement.
-- OnMatchFound intentionally returns the match unchanged. Stock UE4SS already
-- selected and verified this correct retail function entry through its FName
-- verification hook; this is not a validation bypass and does not patch the
-- game or UE4SS. This signature and the unchanged Dawnwalker settings/vtable
-- entries reached smooth gameplay and quick-load with both the RC4 stock DLL
-- and the exact RC5 patched DLL on the supported build. Only comments were
-- updated for this build. Never reuse this signature for a different executable
-- SHA-256 or after an unverified game update.

function Register()
    return "48 89 5C 24 10 48 89 6C 24 18 48 89 74 24 20 57 48 81 EC 40 04 00 00 48 8B 05 ?? ?? ?? ?? 48 33 C4"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end
